﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using WindowsFormsApp1.Classes;
using WindowsFormsApp1.Properties;
using BaseLibrary;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private BindingSource _bsValidData = new BindingSource();
        public Form1()
        {
            InitializeComponent();
            Shown += Form1_Shown;
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            Width = 1500;
            CenterToScreen();


        }

        private void cmdProcess_Click(object sender, EventArgs e)
        {
            var ops = new FileOperations();
            ops.LoadCsvFileOleDb();
            (bool sucess, List<DataItem> validRows, List<InvalidDataItem> invalidRows, _ ) = ops.LoadCsvFileTextFieldParser();
            if (sucess)
            {
                var results = validRows.Select(item => item.NcicCode);
                _bsValidData.DataSource = validRows;
                dataGridView1.DataSource = _bsValidData;

                dataGridView1.Columns["id"].HeaderText = "Row index";
                dataGridView1.Columns["inspect"].DisplayIndex = 0;
                dataGridView1.Columns["Address"].Width = 300;
                dataGridView1.Columns["Description"].Width = 215;

                cboInspectRowIndices.DataSource = validRows.Where(item => item.Inspect).Select(item => item.Id).ToList();

                dataGridView2.DataSource = invalidRows;

                dataGridView2.ExpandColumns();
            }

        }
        private void cmdInspectRows_Click(object sender, EventArgs e)
        {
            if (cboInspectRowIndices.DataSource == null) return;

            var item = _bsValidData.List.OfType<DataItem>()
                .ToList()
                .Find(dataItem => dataItem.Id == Convert.ToInt32(cboInspectRowIndices.Text));

            var pos = _bsValidData.IndexOf(item);
            if (pos > -1)
            {
                _bsValidData.Position = pos;
            }
        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            var now = DateTime.Now;
            var target = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 14, 00, 00);

            //Add 1 day to the target time if we're already at 14:00+ today.
            if (now.Hour >= 14)
                target = target.AddDays(1);

            TimeSpan difference = target - now;

            var timeRemain = difference.ToString(@"hh\:mm\:ss");
            Console.WriteLine(timeRemain);
        }
    }

    /// <summary>
    /// Place this class in it's own file
    /// </summary>
    public static class Extensions
    {
        public static IEnumerable<T> Descendants<T>(this Control control) where T : class
        {
            foreach (Control child in control.Controls)
            {

                T childOfT = child as T;
                if (childOfT != null)
                {
                    yield return (T) childOfT;
                }

                if (!child.HasChildren) continue;
                foreach (T descendant in Descendants<T>(child))
                {
                    yield return descendant;
                }
            }
        }
    }
    public static class DataGridViewExtensions
    {
        /// <summary>
        /// Expand all columns excluding in this case Orders column
        /// </summary>
        /// <param name="sender"></param>
        public static void ExpandColumns(this DataGridView sender)
        {
            sender.Columns.Cast<DataGridViewColumn>().ToList()
                .ForEach(col => col.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells);
        }

    }
}
