﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public class Operations
    {
        /// <summary>
        /// Not all columns are done, just two for showing the pattern
        /// to insert records.
        /// </summary>
        /// <param name="pDataTable"></param>
        /// <returns></returns>
        public bool InsertRecords(DataTable pDataTable)
        {
            bool success = false;

            try
            {
                using (var cn = new SqlConnection() { ConnectionString = "Your connection string" })
                {
                    using (var cmd = new SqlCommand() { Connection = cn })
                    {

                        cmd.CommandText = "INSERT INTO PropertyAssign (Desposition,DateIssued) VALUES (@Desposition,@DateIssued);";

                        cmd.Parameters.Add(new SqlParameter("@desposition", SqlDbType.NVarChar, 21, "Desposition"));
                        cmd.Parameters.Add(new SqlParameter("@IsDate", SqlDbType.Date, 3, "DateIssued"));

                        cn.Open();

                        foreach (DataRow row in pDataTable.Rows)
                        {
                            cmd.Parameters["@desposition"].Value = row.Field<string>("SomeField1") == null ? (object)DBNull.Value : row.Field<string>("SomeField1");
                            cmd.Parameters["@DateIssued"].Value = row.Field<string>("SomeField2") == null ? (object)DBNull.Value : row.Field<string>("SomeField2");

                            Console.WriteLine(cmd.ActualCommandText());

                            cmd.ExecuteNonQuery();
                        }

                        success = true;

                    }
                }
            }
            catch (Exception e)
            {
                /*
                 * If this is just for you then use 
                 */
                Console.WriteLine(e.Message);

                /*
                 * If this is for a customer, consider writing to a log file, send an email and write to a log file
                 */
            }

            return success;
        }

    }
}
